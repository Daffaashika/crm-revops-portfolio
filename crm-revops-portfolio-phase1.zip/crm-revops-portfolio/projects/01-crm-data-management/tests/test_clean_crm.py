"""Tests for the Project 1 generator + cleaning pipeline (synthetic data, fixed seed)."""
import hashlib
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "projects/01-crm-data-management/src"))
from clean_crm import clean_email, clean_tables, evaluate_against_injected, normalize_company_name  # noqa: E402
from validate_data import load_tables, run_checks  # noqa: E402

RAW = ROOT / "projects/01-crm-data-management/data/raw"


@pytest.fixture(scope="module")
def cleaned():
    raw = load_tables(RAW)
    return raw, *clean_tables(raw)


# ---- unit tests -----------------------------------------------------------------
@pytest.mark.parametrize("variant", ["Northwind Labs Inc", "NORTHWIND LABS INC", "northwind labs",
                                     "  Northwind  Labs Inc. ", "Northwind Labs Incorporated"])
def test_company_name_variants_share_one_key(variant):
    assert normalize_company_name(variant) == "northwind labs"


@pytest.mark.parametrize("raw,expected", [
    ("  Jane.Doe@Acme.example ", "jane.doe@acme.example"),
    ("jane.doe@acme", None), ("jane.doe@", None), ("jane.doe acme.example", None),
    ("jane.doe @ acme.example", None), (None, None),
])
def test_clean_email(raw, expected):
    assert clean_email(raw) == expected


# ---- generator ------------------------------------------------------------------
def test_generator_is_deterministic(tmp_path):
    digests = []
    for run in ("a", "b"):
        out = tmp_path / run
        subprocess.run([sys.executable, str(ROOT / "scripts/generate_data.py"), "--seed", "7", "--out", str(out)],
                       check=True, capture_output=True)
        digests.append({p.name: hashlib.md5(p.read_bytes()).hexdigest() for p in sorted((out / "raw").glob("*.csv"))})
    assert digests[0] == digests[1]


def test_ground_truth_is_internally_consistent():
    gt = load_tables(ROOT / "projects/01-crm-data-management/data/ground_truth")
    failed = run_checks(gt)
    hard = failed[~failed["rule"].str.contains("Phone|Job title")]
    assert hard["failed"].sum() == 0, hard[hard["failed"] > 0]


# ---- cleaning pipeline ------------------------------------------------------------
def test_clean_data_passes_all_hard_rules(cleaned):
    _, tables, *_ = cleaned
    res = run_checks(tables)
    hard = res[~res["rule"].str.contains("Phone present|Job title present|Email present")]
    assert hard["failed"].sum() == 0, hard[hard["failed"] > 0]


def test_every_injected_issue_is_caught(cleaned):
    raw, tables, log, rejects, cmap, dmap = cleaned
    ev = evaluate_against_injected(RAW, log, rejects, cmap, dmap)
    assert (ev["recall_pct"] == 100).all(), ev


def test_no_silent_data_loss_for_deals(cleaned):
    raw, tables, log, rejects, cmap, dmap = cleaned
    rejected = set(rejects.loc[rejects.table == "deals", "record_id"])
    assert len(raw["deals"]) == len(tables["deals"]) + len(dmap) + len(rejected)


def test_merged_contacts_are_remapped_everywhere(cleaned):
    _, tables, _, _, cmap, _ = cleaned
    gone = set(cmap["merged_id"])
    assert not gone & set(tables["deals"]["contact_id"])
    assert not gone & set(tables["activities"]["contact_id"])


def test_revenue_only_from_won_deals(cleaned):
    _, tables, *_ = cleaned
    d = tables["deals"]
    assert d.loc[d.status == "Open", "close_date"].isna().all()
    assert d.loc[d.status.isin(["Won", "Lost"]), "close_date"].notna().all()
    assert (d.loc[d.status == "Lost", "lost_reason"].notna()).all()
