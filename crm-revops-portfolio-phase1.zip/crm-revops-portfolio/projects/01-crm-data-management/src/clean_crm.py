"""Reproducible cleaning pipeline for the synthetic CRM export.

Design principles
  * Never silently drop data: every removed/rejected record goes to rejects.csv with a reason.
  * Every merge is recorded (contact_merge_map.csv, deal_merge_map.csv) so it is auditable.
  * Corrections are rule-based and logged in cleaning_log.csv.

Usage:  python projects/01-crm-data-management/src/clean_crm.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
from validate_data import EMAIL_RE, load_tables, parse_iso, run_checks  # noqa: E402

DATA = ROOT / "projects/01-crm-data-management/data"
REPORTS = ROOT / "projects/01-crm-data-management/reports"
_SUFFIX = r"(incorporated|inc|llc|limited|ltd|corporation|corp|company|co)"


def normalize_company_name(name) -> str:
    """Key used to match spelling variants: lowercase, no punctuation, no legal suffix."""
    if not isinstance(name, str):
        return ""
    s = re.sub(r"[^a-z0-9 ]", "", name.lower().replace(".", ""))
    s = re.sub(r"\s+", " ", s).strip()
    return re.sub(rf"\s{_SUFFIX}$", "", s).strip()


def clean_email(value):
    """Trim + lowercase; return None when the format is invalid."""
    if not isinstance(value, str):
        return None
    e = value.strip().lower()
    return e if EMAIL_RE.match(e) else None


def clean_tables(raw: dict[str, pd.DataFrame]):
    log: list[dict] = []
    rejects: list[dict] = []

    def note(table, rid, action, detail=""):
        log.append({"table": table, "record_id": rid, "action": action, "detail": detail})

    def reject(table, rid, reason):
        rejects.append({"table": table, "record_id": rid, "reason": reason})

    companies, users = raw["companies"].copy(), raw["users"].copy()
    contacts, deals = raw["contacts"].copy(), raw["deals"].copy()
    acts, hist = raw["activities"].copy(), raw["deal_stage_history"].copy()

    # ---- Contacts ------------------------------------------------------------
    contacts["email_raw"] = contacts["email"]
    contacts["email"] = contacts["email"].apply(clean_email)
    for _, r in contacts[contacts["email"].isna()].iterrows():
        note("contacts", r["contact_id"], "email_set_null_invalid", str(r["email_raw"]))
    for col in ("first_name", "last_name"):
        contacts[col] = contacts[col].str.strip().str.title()

    # Canonical company name comes from the company master via company_id; the
    # normalised-name key is used to VERIFY that the variant points to the same company.
    master = companies.set_index("company_id")["company_name"]
    key_to_id = {normalize_company_name(n): i for i, n in master.items()}
    resolved = contacts["company_name"].apply(lambda n: key_to_id.get(normalize_company_name(n)))
    for rid in contacts.loc[resolved != contacts["company_id"], "contact_id"]:
        note("contacts", rid, "company_name_unresolvable", "name key did not match company_id")
    changed = contacts["company_name"] != contacts["company_id"].map(master)
    for rid in contacts.loc[changed, "contact_id"]:
        note("contacts", rid, "company_name_standardised")
    contacts["company_name"] = contacts["company_id"].map(master)

    # De-duplicate on normalised valid email; the earliest id (lowest contact_id) survives.
    contacts = contacts.sort_values("contact_id")
    dup = contacts["email"].notna() & contacts["email"].duplicated(keep="first")
    first_by_email = contacts[contacts["email"].notna()].drop_duplicates("email").set_index("email")["contact_id"]
    cmap = contacts.loc[dup, ["contact_id", "email"]].copy()
    cmap["survivor_id"] = cmap["email"].map(first_by_email)
    cmap = cmap.rename(columns={"contact_id": "merged_id"})
    for _, r in cmap.iterrows():
        note("contacts", r["merged_id"], "merged_duplicate", f"survivor={r['survivor_id']}")
    contacts = contacts[~dup].copy()

    # Secondary match: a record whose email was unusable cannot be matched by email, so
    # match on (company_id, first name, last name). Records with a valid email survive first.
    # RISK (documented): two different people with the same name at one company would merge.
    contacts["_name_key"] = (contacts["company_id"] + "|" + contacts["first_name"].str.lower()
                             + "|" + contacts["last_name"].str.lower())
    ranked = contacts.assign(_no_email=contacts["email"].isna()).sort_values(["_no_email", "contact_id"])
    survivor_by_key = ranked.drop_duplicates("_name_key").set_index("_name_key")["contact_id"]
    sec = contacts["email"].isna() & (contacts["_name_key"].map(survivor_by_key) != contacts["contact_id"])
    cmap2 = pd.DataFrame({"merged_id": contacts.loc[sec, "contact_id"],
                          "email": None,
                          "survivor_id": contacts.loc[sec, "_name_key"].map(survivor_by_key)})
    for _, r in cmap2.iterrows():
        note("contacts", r["merged_id"], "merged_duplicate", f"survivor={r['survivor_id']} (name+company match)")
    cmap = pd.concat([cmap, cmap2], ignore_index=True)
    contacts = contacts[~sec].drop(columns=["_name_key"]).copy()
    remap = dict(zip(cmap["merged_id"], cmap["survivor_id"]))
    deals["contact_id"] = deals["contact_id"].replace(remap)
    acts["contact_id"] = acts["contact_id"].replace(remap)

    # ---- Deals ---------------------------------------------------------------
    key = ["company_id", "owner_id", "lead_source", "amount", "created_date", "stage"]
    deals = deals.sort_values("deal_id")
    # amount may be NaN, so build the key from strings to keep NaN == NaN for matching
    keyed = deals[key].fillna("<missing>").astype(str).agg("|".join, axis=1)
    ddup = keyed.duplicated(keep="first")
    first_deal = dict(zip(keyed[~ddup], deals.loc[~ddup, "deal_id"]))
    dmap = pd.DataFrame({"merged_id": deals.loc[ddup, "deal_id"],
                         "survivor_id": keyed[ddup].map(first_deal)})
    for _, r in dmap.iterrows():
        note("deals", r["merged_id"], "merged_duplicate", f"survivor={r['survivor_id']}")
    deals = deals[~ddup].copy()

    # Status conflict: open deals must not carry a close_date (status is treated as authoritative).
    fix = (deals["status"] == "Open") & deals["close_date"].notna()
    for rid in deals.loc[fix, "deal_id"]:
        note("deals", rid, "close_date_cleared_open_deal")
    deals.loc[fix, "close_date"] = None

    created, close = parse_iso(deals["created_date"]), parse_iso(deals["close_date"])
    amt = pd.to_numeric(deals["amount"], errors="coerce")
    checks = {
        "invalid_created_date": created.isna(),
        "invalid_close_date_format": deals["close_date"].notna() & close.isna(),
        "close_date_before_created": close.notna() & (close < created),
        "missing_amount": amt.isna(),
        "non_positive_amount": amt.notna() & (amt <= 0),
    }
    any_fail = pd.Series(False, index=deals.index)
    for name, mask in checks.items():  # one reject row per failed rule, so multi-issue records stay traceable
        for rid in deals.loc[mask, "deal_id"]:
            reject("deals", rid, name)
        any_fail |= mask
    deals = deals[~any_fail].copy()
    deals["amount"] = pd.to_numeric(deals["amount"])

    # ---- Dependent tables ------------------------------------------------------
    orphan = ~acts["deal_id"].isin(deals["deal_id"])
    for rid in acts.loc[orphan, "activity_id"]:
        reject("activities", rid, "parent_deal_rejected")
    acts = acts[~orphan].copy()
    hist = hist[hist["deal_id"].isin(deals["deal_id"])].copy()

    contacts = contacts.drop(columns=["email_raw"])
    tables = {"users": users, "companies": companies, "contacts": contacts, "deals": deals,
              "deal_stage_history": hist, "activities": acts}
    return tables, pd.DataFrame(log), pd.DataFrame(rejects), cmap, dmap


def evaluate_against_injected(raw_dir: Path, log, rejects, cmap, dmap) -> pd.DataFrame:
    """Compare what the cleaner caught with what the generator injected.

    This is only possible because the data is synthetic and the injections were logged.
    """
    inj = pd.read_csv(raw_dir / "injected_issues_log.csv")
    rows = []

    def row(issue, caught, injected):
        hit = len(caught & injected)
        rows.append({"issue_type": issue, "injected": len(injected), "caught": hit,
                     "recall_pct": round(100 * hit / max(1, len(injected)), 1)})

    ids = lambda t: set(inj.loc[inj.issue_type == t, "record_id"])
    rej = lambda r: set(rejects.loc[rejects.reason == r, "record_id"]) if len(rejects) else set()
    act = lambda a: set(log.loc[log.action == a, "record_id"])
    row("duplicate_contact", set(cmap["merged_id"]), ids("duplicate_contact"))
    row("duplicate_deal", set(dmap["merged_id"]), ids("duplicate_deal"))
    row("invalid_date", rej("invalid_close_date_format") | rej("close_date_before_created"), ids("invalid_date"))
    row("missing_amount", rej("missing_amount") | set(dmap["merged_id"]), ids("missing_amount"))
    row("negative_amount", rej("non_positive_amount") | set(dmap["merged_id"]), ids("negative_amount"))
    row("invalid_email", act("email_set_null_invalid"), ids("invalid_email"))
    row("inconsistent_company_name", act("company_name_standardised"), ids("inconsistent_company_name"))
    row("open_deal_with_close_date", act("close_date_cleared_open_deal") | set(dmap["merged_id"]),
        ids("open_deal_with_close_date"))
    return pd.DataFrame(rows)


def main() -> None:
    raw_dir = DATA / "raw"
    raw = load_tables(raw_dir)
    tables, log, rejects, cmap, dmap = clean_tables(raw)

    (DATA / "clean").mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        df.to_csv(DATA / "clean" / f"{name}.csv", index=False)
    log.to_csv(REPORTS / "cleaning_log.csv", index=False)
    rejects.to_csv(REPORTS / "rejects.csv", index=False)
    cmap.to_csv(REPORTS / "contact_merge_map.csv", index=False)
    dmap.to_csv(REPORTS / "deal_merge_map.csv", index=False)

    before, after = run_checks(raw), run_checks(load_tables(DATA / "clean"))
    cmp_ = before.merge(after, on=["rule", "table"], suffixes=("_before", "_after"))
    cmp_.to_csv(REPORTS / "quality_before_after.csv", index=False)
    ev = evaluate_against_injected(raw_dir, log, rejects, cmap, dmap)
    ev.to_csv(REPORTS / "detection_vs_injected.csv", index=False)
    counts = pd.DataFrame({"table": list(tables), "raw_rows": [len(raw[t]) for t in tables],
                           "clean_rows": [len(tables[t]) for t in tables]})
    counts.to_csv(REPORTS / "row_counts.csv", index=False)

    print(counts.to_string(index=False))
    print("\nFailed records per rule (before -> after):")
    print(cmp_[["rule", "failed_before", "failed_after"]].to_string(index=False))
    print("\nDetection vs injected:")
    print(ev.to_string(index=False))


if __name__ == "__main__":
    main()
