"""Generate a SYNTHETIC B2B SaaS CRM dataset for the portfolio.

Everything produced here is fictional. Company names, people, amounts and
outcomes are randomly generated with a fixed seed so results are reproducible.

Outputs (under projects/01-crm-data-management/data/):
  ground_truth/  - internally consistent "true" tables (before corruption)
  raw/           - the same tables with deliberately injected data-quality issues
  raw/injected_issues_log.csv - one row per injected issue (used to test the cleaner)

Usage:
    python scripts/generate_data.py [--seed 42] [--out <dir>]
"""
from __future__ import annotations

import argparse
import random
from pathlib import Path

import numpy as np
import pandas as pd

AS_OF_DATE = pd.Timestamp("2026-09-30")  # fixed "today" so KPIs are reproducible
START_DATE = pd.Timestamp("2025-01-01")

STAGES = ["Qualified", "Discovery", "Proposal", "Negotiation"]  # open stages, in order
WON, LOST = "Closed Won", "Closed Lost"
# Probability that a deal advances out of each open stage (last one -> Closed Won)
ADVANCE_P = {"Qualified": 0.86, "Discovery": 0.78, "Proposal": 0.72, "Negotiation": 0.76}
# Typical days spent in each stage (mean of a gamma-like draw)
STAGE_DAYS = {"Qualified": 14, "Discovery": 22, "Proposal": 25, "Negotiation": 18}

SOURCES = {  # name: (share of deals, win-rate multiplier)
    "Inbound Web": (0.26, 1.00),
    "Outbound SDR": (0.24, 0.80),
    "Referral": (0.14, 1.35),
    "Partner": (0.12, 1.15),
    "Webinar": (0.10, 0.90),
    "Paid Ads": (0.09, 0.75),
    "Trade Show": (0.05, 0.95),
}
LOST_REASONS = {
    "Price too high": 0.28, "Chose competitor": 0.24, "No decision / went dark": 0.22,
    "Missing feature": 0.10, "Budget freeze": 0.09, "Bad timing": 0.07,
}
OWNERS = [
    ("U01", "Amelia Hart", "AE"), ("U02", "Rafael Ortiz", "AE"), ("U03", "Nadia Rahman", "AE"),
    ("U04", "Tomas Weber", "AE"), ("U05", "Chloe Nguyen", "AE"), ("U06", "Dev Patel", "AE"),
]
OWNER_SKILL = {"U01": 1.15, "U02": 1.0, "U03": 1.1, "U04": 0.85, "U05": 0.95, "U06": 0.75}
INDUSTRIES = ["Software", "Healthcare", "Logistics", "Retail", "Education", "Fintech", "Manufacturing"]
SEGMENTS = {"SMB": (0.55, 4_000, 0.5), "Mid-Market": (0.33, 16_000, 0.45), "Enterprise": (0.12, 60_000, 0.4)}
COUNTRIES = ["United States", "United Kingdom", "Australia", "Singapore", "Canada", "Germany"]
FIRST = ["Liam", "Olivia", "Noah", "Emma", "Ava", "Lucas", "Mia", "Ethan", "Sofia", "Mason", "Isla", "Aiden",
         "Zara", "Omar", "Priya", "Kenji", "Lena", "Mateo", "Aisha", "Hugo", "Freya", "Ravi", "Maya", "Jonas"]
LAST = ["Clark", "Nguyen", "Patel", "Silva", "Kim", "Fischer", "Rossi", "Brown", "Lopez", "Tan", "Morris",
        "Hughes", "Santos", "Novak", "Ibrahim", "Larsen", "Chen", "Dubois", "Walker", "Reyes"]
CO_A = ["Northwind", "Bluepeak", "Ironleaf", "Quillon", "Brightmoor", "Tidewater", "Halcyon", "Redfern",
        "Stonebridge", "Lumina", "Cobalt", "Fernhill", "Oakridge", "Silverline", "Pinecrest", "Harborview",
        "Ashford", "Kestrel", "Marlow", "Verity", "Summit", "Larkspur", "Ember", "Wexford", "Zenith"]
CO_B = ["Systems", "Labs", "Logistics", "Health", "Retail", "Learning", "Capital", "Works", "Group", "Digital"]
SUFFIXES = ["Inc", "LLC", "Ltd", "Corp", "Co"]
JOB_TITLES = ["Operations Manager", "VP Sales", "Head of Marketing", "IT Director", "CFO", "COO",
              "RevOps Lead", "Founder", "Procurement Manager", "Customer Success Lead"]
ACTIVITY_TYPES = ["Call", "Email", "Meeting", "Demo", "Follow-up Task"]


def make_companies(rng: random.Random, n: int = 160) -> pd.DataFrame:
    names: set[str] = set()
    rows = []
    seg_names = list(SEGMENTS)
    seg_w = [SEGMENTS[s][0] for s in seg_names]
    while len(rows) < n:
        base = f"{rng.choice(CO_A)} {rng.choice(CO_B)}"
        if base in names:
            continue
        names.add(base)
        cid = f"C{len(rows) + 1:04d}"
        seg = rng.choices(seg_names, seg_w)[0]
        rows.append({
            "company_id": cid,
            "company_name": f"{base} {rng.choice(SUFFIXES)}",
            "industry": rng.choice(INDUSTRIES),
            "segment": seg,
            "country": rng.choice(COUNTRIES),
            "created_date": (START_DATE - pd.Timedelta(days=rng.randint(30, 400))).date().isoformat(),
        })
    return pd.DataFrame(rows)


def make_contacts(rng: random.Random, companies: pd.DataFrame) -> pd.DataFrame:
    rows, used_emails = [], set()
    for _, co in companies.iterrows():
        domain = co["company_name"].lower().rsplit(" ", 1)[0].replace(" ", "") + ".example"
        for _ in range(rng.randint(1, 4)):
            first, last = rng.choice(FIRST), rng.choice(LAST)
            email = f"{first.lower()}.{last.lower()}@{domain}"
            if email in used_emails:
                continue
            used_emails.add(email)
            rows.append({
                "contact_id": f"P{len(rows) + 1:05d}",
                "company_id": co["company_id"],
                "first_name": first, "last_name": last, "email": email,
                "phone": f"+1-555-{rng.randint(100, 999)}-{rng.randint(1000, 9999)}",
                "job_title": rng.choice(JOB_TITLES),
                "created_date": (pd.Timestamp(co["created_date"]) + pd.Timedelta(days=rng.randint(0, 200))).date().isoformat(),
            })
    return pd.DataFrame(rows)


def make_deals(rng: random.Random, nrng: np.random.Generator, companies, contacts, n: int = 650):
    """Create deals, their stage history, and activities. All dates <= AS_OF_DATE."""
    src_names = list(SOURCES)
    src_w = [SOURCES[s][0] for s in src_names]
    by_company = contacts.groupby("company_id")["contact_id"].apply(list).to_dict()
    seg_of = companies.set_index("company_id")["segment"].to_dict()
    span = (AS_OF_DATE - START_DATE).days

    deals, history, activities = [], [], []
    for i in range(n):
        deal_id = f"D{i + 1:05d}"
        co = companies.iloc[rng.randrange(len(companies))]
        cid = co["company_id"]
        contact_id = rng.choice(by_company[cid])
        owner_id, _, _ = rng.choice(OWNERS)
        source = rng.choices(src_names, src_w)[0]
        # More deals created later in the window (growing business)
        created = START_DATE + pd.Timedelta(days=int(span * (rng.random() ** 0.55)))
        _, mean_amt, sigma = SEGMENTS[seg_of[cid]]
        amount = float(round(nrng.lognormal(np.log(mean_amt), sigma) / 100) * 100)
        win_mult = SOURCES[source][1] * OWNER_SKILL[owner_id] * (0.85 if seg_of[cid] == "Enterprise" else 1.0)

        # Walk the funnel
        cursor = created
        stage_idx, outcome = 0, None
        history.append({"deal_id": deal_id, "stage": STAGES[0], "entered_date": cursor.date().isoformat()})
        while outcome is None:
            stage = STAGES[stage_idx]
            days = max(2, int(nrng.gamma(2.0, STAGE_DAYS[stage] / 2.0)))
            leave = cursor + pd.Timedelta(days=days)
            if leave > AS_OF_DATE:  # still sitting in this stage as of the snapshot
                break
            p = min(0.95, ADVANCE_P[stage] * (win_mult ** 0.5 if stage_idx == 3 else win_mult ** 0.25))
            cursor = leave
            if rng.random() < p:
                if stage_idx == len(STAGES) - 1:
                    outcome = WON
                else:
                    stage_idx += 1
                    history.append({"deal_id": deal_id, "stage": STAGES[stage_idx], "entered_date": cursor.date().isoformat()})
            else:
                outcome = LOST
        if outcome:
            history.append({"deal_id": deal_id, "stage": outcome, "entered_date": cursor.date().isoformat()})
            status, close_date, current_stage = ("Won" if outcome == WON else "Lost"), cursor, outcome
            expected = created + pd.Timedelta(days=int((close_date - created).days * rng.uniform(0.8, 1.3)) + 5)
            reason = None if outcome == WON else rng.choices(list(LOST_REASONS), list(LOST_REASONS.values()))[0]
        else:
            status, close_date, current_stage, reason = "Open", None, STAGES[stage_idx], None
            expected = created + pd.Timedelta(days=int(rng.uniform(35, 95)))  # some will be overdue
        deals.append({
            "deal_id": deal_id, "company_id": cid, "contact_id": contact_id, "owner_id": owner_id,
            "lead_source": source, "deal_name": f"{co['company_name']} - {rng.choice(['New Logo', 'Expansion'])}",
            "amount": amount, "currency": "USD", "stage": current_stage, "status": status,
            "created_date": created.date().isoformat(),
            "expected_close_date": expected.date().isoformat(),
            "close_date": close_date.date().isoformat() if close_date is not None else None,
            "lost_reason": reason,
        })
        # Activities between creation and close (or snapshot)
        end = close_date if close_date is not None else AS_OF_DATE
        for _ in range(rng.randint(2, 10)):
            d = created + pd.Timedelta(days=rng.randint(0, max(0, (end - created).days)))
            activities.append({
                "deal_id": deal_id, "contact_id": contact_id, "owner_id": owner_id,
                "activity_type": rng.choice(ACTIVITY_TYPES), "activity_date": d.date().isoformat(),
            })
    deals_df = pd.DataFrame(deals)
    acts_df = pd.DataFrame(activities).sort_values(["activity_date", "deal_id"]).reset_index(drop=True)
    acts_df.insert(0, "activity_id", [f"A{i + 1:06d}" for i in range(len(acts_df))])
    return deals_df, pd.DataFrame(history), acts_df


# --------------------------------------------------------------------------- corruption
def _variant(name: str, rng: random.Random) -> str:
    """Return an inconsistent spelling of a company name."""
    base, suffix = name.rsplit(" ", 1)
    choice = rng.choice(["upper", "lower", "nosuffix", "dotted", "spaces", "longsuffix"])
    if choice == "upper":
        return name.upper()
    if choice == "lower":
        return name.lower()
    if choice == "nosuffix":
        return base
    if choice == "dotted":
        return f"{base} {suffix}."
    if choice == "spaces":
        return f"  {base}  {suffix} "
    return f"{base} {dict(Inc='Incorporated', LLC='L.L.C.', Ltd='Limited', Corp='Corporation', Co='Company')[suffix]}"


def corrupt(rng: random.Random, companies, contacts, deals, activities):
    """Inject documented issues. Returns raw tables + issue log."""
    log: list[dict] = []

    def note(table, record_id, issue, detail=""):
        log.append({"table": table, "record_id": record_id, "issue_type": issue, "detail": detail})

    contacts, deals, activities = contacts.copy(), deals.copy(), activities.copy()
    co_name = companies.set_index("company_id")["company_name"].to_dict()
    # Raw contacts carry a denormalised company_name (typical of CRM imports)
    contacts["company_name"] = contacts["company_id"].map(co_name)

    # 1) inconsistent company names (~12% of contacts)
    for idx in rng.sample(list(contacts.index), int(len(contacts) * 0.12)):
        contacts.at[idx, "company_name"] = _variant(contacts.at[idx, "company_name"], rng)
        note("contacts", contacts.at[idx, "contact_id"], "inconsistent_company_name")

    # 2) invalid emails (~4%)
    for idx in rng.sample(list(contacts.index), int(len(contacts) * 0.04)):
        e = contacts.at[idx, "email"]
        bad = rng.choice([e.replace("@", ""), e.split("@")[0] + "@", e.replace(".example", ""), e.replace("@", " @ ")])
        contacts.at[idx, "email"] = bad
        note("contacts", contacts.at[idx, "contact_id"], "invalid_email", bad)

    # 3) missing values
    for col, share, issue in [("phone", 0.10, "missing_phone"), ("job_title", 0.08, "missing_job_title")]:
        for idx in rng.sample(list(contacts.index), int(len(contacts) * share)):
            contacts.at[idx, col] = None
            note("contacts", contacts.at[idx, "contact_id"], issue)

    # 4) duplicate contacts (~6%): new id, email case/whitespace changed, some deals/activities re-pointed
    next_id = len(contacts) + 1
    dup_rows = []
    valid_idx = [i for i in contacts.index if "@" in str(contacts.at[i, "email"]) and "." in str(contacts.at[i, "email"]).split("@")[-1]]
    for idx in rng.sample(valid_idx, int(len(contacts) * 0.06)):
        src = contacts.loc[idx].copy()
        new_id = f"P{next_id:05d}"
        next_id += 1
        orig_id = src["contact_id"]
        src["contact_id"] = new_id
        src["email"] = rng.choice([src["email"].upper(), f" {src['email']} ", src["email"].capitalize()])
        dup_rows.append(src)
        note("contacts", new_id, "duplicate_contact", f"duplicate_of={orig_id}")
        for d_idx in deals.index[deals["contact_id"] == orig_id]:
            if rng.random() < 0.5:
                deals.at[d_idx, "contact_id"] = new_id
        for a_idx in activities.index[activities["contact_id"] == orig_id]:
            if rng.random() < 0.4:
                activities.at[a_idx, "contact_id"] = new_id
    contacts = pd.concat([contacts, pd.DataFrame(dup_rows)], ignore_index=True)

    # 5) invalid / illogical dates in deals (~2.5%)
    closed = [i for i in deals.index if pd.notna(deals.at[i, "close_date"])]
    for idx in rng.sample(closed, int(len(closed) * 0.04)):
        kind = rng.choice(["before_created", "bad_format"])
        if kind == "before_created":
            deals.at[idx, "close_date"] = (pd.Timestamp(deals.at[idx, "created_date"]) - pd.Timedelta(days=rng.randint(1, 30))).date().isoformat()
        else:
            deals.at[idx, "close_date"] = rng.choice(["31/02/2026", "2026-13-05", "N/A", "tomorrow"])
        note("deals", deals.at[idx, "deal_id"], "invalid_date", f"{kind}: {deals.at[idx, 'close_date']}")

    # 6) invalid / missing amounts
    for idx in rng.sample(list(deals.index), int(len(deals) * 0.02)):
        deals.at[idx, "amount"] = None
        note("deals", deals.at[idx, "deal_id"], "missing_amount")
    for idx in rng.sample(list(deals.index), int(len(deals) * 0.01)):
        if pd.notna(deals.at[idx, "amount"]):
            deals.at[idx, "amount"] = -abs(deals.at[idx, "amount"])
            note("deals", deals.at[idx, "deal_id"], "negative_amount")

    # 7) duplicate deals (~3%): same business content, new deal_id
    next_d = len(deals) + 1
    dup_deals = []
    for idx in rng.sample(list(deals.index), int(len(deals) * 0.03)):
        row = deals.loc[idx].copy()
        orig = row["deal_id"]
        row["deal_id"] = f"D{next_d:05d}"
        next_d += 1
        dup_deals.append(row)
        note("deals", row["deal_id"], "duplicate_deal", f"duplicate_of={orig}")
    deals = pd.concat([deals, pd.DataFrame(dup_deals)], ignore_index=True)

    # 8) Closed Won with a lost reason / Open with a close date (status-field conflicts) ~1%
    open_idx = [i for i in deals.index if deals.at[i, "status"] == "Open"]
    for idx in rng.sample(open_idx, max(1, int(len(open_idx) * 0.06))):
        deals.at[idx, "close_date"] = deals.at[idx, "created_date"]
        note("deals", deals.at[idx, "deal_id"], "open_deal_with_close_date")

    return contacts, deals, activities, pd.DataFrame(log)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "projects/01-crm-data-management/data"))
    args = ap.parse_args()

    rng, nrng = random.Random(args.seed), np.random.default_rng(args.seed)
    out = Path(args.out)
    for sub in ("ground_truth", "raw", "clean"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    users = pd.DataFrame(OWNERS, columns=["owner_id", "owner_name", "role"])
    companies = make_companies(rng)
    contacts = make_contacts(rng, companies)
    deals, history, activities = make_deals(rng, nrng, companies, contacts)

    gt = out / "ground_truth"
    for name, df in [("users", users), ("companies", companies), ("contacts", contacts),
                     ("deals", deals), ("deal_stage_history", history), ("activities", activities)]:
        df.to_csv(gt / f"{name}.csv", index=False)

    raw_contacts, raw_deals, raw_acts, log = corrupt(rng, companies, contacts, deals, activities)
    raw = out / "raw"
    for name, df in [("users", users), ("companies", companies), ("contacts", raw_contacts),
                     ("deals", raw_deals), ("deal_stage_history", history), ("activities", raw_acts),
                     ("injected_issues_log", log)]:
        df.to_csv(raw / f"{name}.csv", index=False)

    print(f"seed={args.seed} companies={len(companies)} contacts={len(raw_contacts)} "
          f"deals={len(raw_deals)} activities={len(raw_acts)} injected_issues={len(log)}")
    print(log["issue_type"].value_counts().to_string())


if __name__ == "__main__":
    main()
