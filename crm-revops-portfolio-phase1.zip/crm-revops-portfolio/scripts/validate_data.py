"""Rule-based data-quality validation for the synthetic CRM tables.

Each rule returns the number of FAILING records and the number of records checked,
so every rule has a clear denominator. Used on both raw and cleaned data.
"""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

EMAIL_RE = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)+$")


def load_tables(folder: Path) -> dict[str, pd.DataFrame]:
    names = ["users", "companies", "contacts", "deals", "deal_stage_history", "activities"]
    return {n: pd.read_csv(Path(folder) / f"{n}.csv", dtype=str, keep_default_na=False, na_values=[""]) for n in names}


def parse_iso(series: pd.Series) -> pd.Series:
    """Strict YYYY-MM-DD parsing; anything else becomes NaT."""
    return pd.to_datetime(series, format="%Y-%m-%d", errors="coerce")


def run_checks(t: dict[str, pd.DataFrame]) -> pd.DataFrame:
    c, d, a, u, co = t["contacts"], t["deals"], t["activities"], t["users"], t["companies"]
    rows: list[tuple[str, str, int, int]] = []

    def add(rule: str, table: str, failed: int, total: int) -> None:
        rows.append((rule, table, int(failed), int(total)))

    # Uniqueness of primary keys
    add("PK unique: contact_id", "contacts", c["contact_id"].duplicated().sum(), len(c))
    add("PK unique: deal_id", "deals", d["deal_id"].duplicated().sum(), len(d))

    # Contacts
    email_norm = c["email"].fillna("").str.strip().str.lower()
    add("Email present", "contacts", c["email"].isna().sum(), len(c))
    has_email = c["email"].notna()
    add("Email has valid format (when present)", "contacts",
        (~email_norm[has_email].apply(lambda e: bool(EMAIL_RE.match(e)))).sum(), has_email.sum())
    valid_email = email_norm[email_norm.apply(lambda e: bool(EMAIL_RE.match(e)))]
    add("No duplicate contacts (same normalised email)", "contacts", valid_email.duplicated().sum(), len(valid_email))
    add("Phone present", "contacts", c["phone"].isna().sum(), len(c))
    add("Job title present", "contacts", c["job_title"].isna().sum(), len(c))
    if "company_name" in c.columns:
        master = c["company_id"].map(co.set_index("company_id")["company_name"])
        add("Company name matches master record exactly", "contacts", (c["company_name"] != master).sum(), len(c))

    # Deals: dates
    created, close, expected = parse_iso(d["created_date"]), parse_iso(d["close_date"]), parse_iso(d["expected_close_date"])
    has_close_text = d["close_date"].notna()
    add("close_date parses as YYYY-MM-DD", "deals", (has_close_text & close.isna()).sum(), has_close_text.sum())
    both = close.notna() & created.notna()
    add("close_date >= created_date", "deals", (close[both] < created[both]).sum(), both.sum())
    add("Open deals have no close_date", "deals", ((d["status"] == "Open") & has_close_text).sum(), (d["status"] == "Open").sum())
    closed_mask = d["status"].isin(["Won", "Lost"])
    add("Closed deals have a close_date", "deals", (closed_mask & ~has_close_text).sum(), closed_mask.sum())
    add("expected_close_date >= created_date", "deals", (expected < created).sum(), len(d))

    # Deals: values
    amt = pd.to_numeric(d["amount"], errors="coerce")
    add("Amount present", "deals", amt.isna().sum(), len(d))
    add("Amount > 0", "deals", (amt <= 0).sum(), amt.notna().sum())
    lost = d["status"] == "Lost"
    add("Lost deals have a lost_reason", "deals", (lost & d["lost_reason"].isna()).sum(), lost.sum())
    key = ["company_id", "owner_id", "lead_source", "amount", "created_date", "stage"]
    add("No duplicate deals (same business key)", "deals", d.duplicated(subset=key).sum(), len(d))

    # Referential integrity
    add("FK: deals.company_id in companies", "deals", (~d["company_id"].isin(co["company_id"])).sum(), len(d))
    add("FK: deals.contact_id in contacts", "deals", (~d["contact_id"].isin(c["contact_id"])).sum(), len(d))
    add("FK: deals.owner_id in users", "deals", (~d["owner_id"].isin(u["owner_id"])).sum(), len(d))
    add("FK: activities.deal_id in deals", "activities", (~a["deal_id"].isin(d["deal_id"])).sum(), len(a))
    add("FK: activities.contact_id in contacts", "activities", (~a["contact_id"].isin(c["contact_id"])).sum(), len(a))

    out = pd.DataFrame(rows, columns=["rule", "table", "failed", "checked"])
    out["pass_rate_pct"] = ((1 - out["failed"] / out["checked"].clip(lower=1)) * 100).round(1)
    return out


if __name__ == "__main__":
    import sys
    folder = Path(sys.argv[1])
    print(run_checks(load_tables(folder)).to_string(index=False))
